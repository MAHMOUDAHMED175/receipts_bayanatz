import 'package:flutter/material.dart';

class ColorsApp {
  static Color scaffoldColor = Colors.grey[300]!;
  static Color AppBarColor = Colors.orange;

  // static Color fillWhiteColorTextFormField=Colors.white;
  // static Color fillGreyColorTextFormField=Colors.grey;
  // static Color fillTealColorTextFormField=Colors.teal;
  static Color whiteColor = Colors.white;
  static Color blackColor = Colors.black;
  static Color defualtColor = Colors.orange;

  // static Color buttonColor=Colors.teal;
  // static Color buttonColorGreyOpacity=Colors.grey.withOpacity(0.2);

  // static Color whiteCard = Colors.white;

  static Color whiteText = Colors.white;
  static Color blackText = Colors.black;
}

class AssetsImages {
  static const logo = 'assets/images/logo.png';
  static const receipts = 'assets/images/receipt.jpg';
  static const invoicetemplate = 'assets/images/invoice-template.jpg';
  static const transactionreceipt = 'assets/images/transaction-receipt.jpg';
}

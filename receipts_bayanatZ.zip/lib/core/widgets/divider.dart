import 'package:flutter/material.dart';

Widget myDivider()=>Padding(
  padding: const EdgeInsetsDirectional.only(
    start: 35.0,
    end: 30,
  ),
  child: Container(
    height: 2.0,
    color: Colors.grey,
  ),
);

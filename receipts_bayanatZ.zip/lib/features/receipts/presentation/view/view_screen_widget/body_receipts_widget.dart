import 'package:flutter/material.dart' hide Image;
import 'package:flutter/material.dart';




Widget  contentReceiptsWidget(){
  return Container();
}
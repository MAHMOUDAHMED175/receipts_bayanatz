
abstract class ReceiptState {}

class ReceiptInitial extends ReceiptState {}






class devicesMsgReceiptState extends ReceiptState {}
class devicesReceiptState extends ReceiptState {}
